# Download the video lectures on windows

There are 3 different ways to download the video lectures, each has it's *one click downloader*, you could download from YouTube or from the original source.

## How to download from source, best quality.

1. Double click on 'download-from-source.bat'.
2. A command prompt will open and the download will begin automatically.

The videos will be named 'Miller_MUS171_Lecture01' and '02' and so on. When the 20 video lectures finish downloading you can close the command window.


## How to download from YouTube, worst quality.

 
1. Double click on one of the playlist downloaders, you can try with 'download-from-playlist-by-sqdr.bat' or 'download-from-playlist-by-toitoitoy.bat'.
2. A command prompt will open and the download will begin automatically.
3. If it gave you an error try the other playlist downloader.


The videos will be named 'Miller_MUS171_Lecture01' and '02' and so on. When the 20 video lectures finish downloading you can close the command window.